function nanohubGUI_sec013_team18
% Either of the following function names typed into the command window will
% open the simulation suite:
%
% - nanohubGUI_sec013_team18
% - nanohubGUI_sec13_team18

nanohubGUI_sec13_team18;
end